import {
  BsBell,
  BsFillPersonFill,
  BsSearch,
  BsPlusLg,
  BsTwitter,
} from "react-icons/bs";
import { AiOutlineInfoCircle, AiOutlineMenu } from "react-icons/ai";
import { RxCopy, RxDashboard } from "react-icons/rx";
import bar from "./assets/bar.jpeg";
import line from "./assets/line.jpeg";

export default function App() {
  return (
    <>
      <div className="container mx-auto">
        <main className="h-full">
          <div className="flex relative">
            <aside className="sticky overflow-auto top-0 w-full bg-white hidden lg:block h-screen max-w-xs px-10 py-8">
              <div className="p-12 bg-red-600 flex items-center justify-center rounded-xl w-[200px]">
                <BsFillPersonFill size={50} color="#fff" />
              </div>
              <div className="flex flex-col gap-y-8 mt-6">
                <h1 className="text-black font-bold text-3xl">John Doe</h1>
                <p className="uppercase font-medium text-xl text-red-700">
                  main
                </p>
                <p className="font-medium text-xl text-gray-600">Dashboard</p>
                <p className="font-medium text-xl text-gray-600">
                  User Profile
                </p>
                <p className="font-medium text-xl text-gray-600">Table List</p>
                <p className="font-medium text-xl text-gray-600">Maps</p>
                <p className="font-medium text-xl text-gray-600">
                  Notifications
                </p>
              </div>
              <div className="flex gap-x-4 items-center mt-10">
                <AiOutlineMenu size={30} />
                <span>More</span>
              </div>
            </aside>
            <section className="w-full px-8 py-6">
              <div className="flex items-center justify-between pb-2">
                <h1 className="text-2xl sm:text-3xl font-bold text-black">
                  Material Dashboard
                </h1>
                <div className="flex gap-x-6 items-center">
                  <div className="flex items center border-b-2 border-gray-900 mr-3 ">
                    <input
                      type="text"
                      className="outline-0 focus:outline-0 bg-[#f5f5f5]"
                    />
                    <BsSearch size={15} />
                  </div>
                  <RxDashboard size={15} />
                  <BsBell size={15} />
                  <BsFillPersonFill size={15} />
                </div>
              </div>
              <button className="mt-6 rounded-full bg-purple-900 text-white flex items-center gap-x-4 py-3 px-6">
                <BsPlusLg size={15} />
                <span>Add widget</span>
              </button>
              <div className="mt-16 grid grid-cols-2 gap-10">
                <div className="rounded-xl bg-white p-4">
                  <h2 className="font-bold text-xl pb-2 border-b-2 border-purple-900 mb-6">
                    Daily sales
                  </h2>
                  <p className="text-gray-600 text-sm mb-2">
                    Lorem ipsum dolor sit, amet <br /> consectetur adipisicing
                    elit.
                  </p>
                  <img
                    src={line}
                    alt="line-chart"
                    className="w-full object-contain h-[200px]"
                  />
                </div>
                <div className="rounded-xl bg-white p-4 ">
                  <h2 className="font-bold text-xl pb-2 border-b-2 border-red-600 mb-6">
                    Email subscriptions
                  </h2>
                  <p className="text-gray-600 text-sm mb-2">
                    Lorem ipsum dolor sit, amet <br /> consectetur adipisicing
                    elit.
                  </p>
                  <img
                    src={bar}
                    alt="bar-chart"
                    className="w-full object-contain h-[200px]"
                  />
                </div>
              </div>
              <div className="mt-10 grid grid-cols-3 gap-10 mb-10">
                <div className="bg-white p-4 relative">
                  <h2 className="font-bold pb-2 border-b-2 border-green-600 text-gray-500 text-lg mb-6">
                    Used Space
                  </h2>
                  <p className="text-2xl font-semibold">
                    49/50<sub>GB</sub>
                  </p>
                  <div className="absolute -bottom-4 right-4 text-white bg-green-600 p-4 rounded-full">
                    <RxCopy size={20} />
                  </div>
                </div>
                <div className="bg-white p-4 relative">
                  <h2 className="font-bold text-gray-500 text-lg pb-2 border-b-2 border-red-600 mb-6">
                    Fixed Issues
                  </h2>
                  <p className="text-2xl font-semibold">75</p>
                  <div className="absolute -bottom-4 right-4 text-white bg-pink-600 p-4 rounded-full">
                    <AiOutlineInfoCircle size={20} />
                  </div>
                </div>
                <div className=" bg-white p-4 relative">
                  <h2 className="font-bold text-gray-500 text-lg pb-2 border-b-2 border-red-600 mb-6">
                    Followers
                  </h2>
                  <p className="text-2xl font-semibold">245</p>
                  <div className="absolute -bottom-4 right-4 text-white bg-blue-600 p-4 rounded-full">
                    <BsTwitter size={20} />
                  </div>
                </div>
              </div>
            </section>
          </div>
        </main>
      </div>
    </>
  );
}
